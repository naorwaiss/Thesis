# explain about the pcb:
    the file of the pcb save as jason and can be open at easyeda 



# scamatic:
![alt text](../picture/scahmtics.png)

# pcb layout:
![alt text](../picture/pcb_routing.png)

# pcb 3d:
![alt text](../picture/3d_pcb.png)

### mission to fix:
    1) at one of the driver of the motor i routing somtings worngs -> need to fix this problem 
    2) need to add a location for the lidar that connect to the teensy 