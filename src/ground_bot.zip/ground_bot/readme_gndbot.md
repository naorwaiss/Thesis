# gnd_bot_deco 

## explain
    this is the part of the code that play the gnd bot 
    this code connect the teensy and the jetson orin 

## arduino part 
    the arduino part was build at name space 
    the arduino send data about:
        1) the motor pwm 
        2) motor velcoity 
        
    the arduino build at name space -> for clean code 
    

## python part - > run on the jetson 
    the python part publish ros2 topic about the bot 


### mission open at the bot part 
    1) make with say the pid for the motor 
    2) send the data about the gnd_bot  
    3) kynamatics and etc - > need to ask shay 
    4) connect the single eye lidar -> need to rhink how mach single eye lidar i need 
    5) need to add some quart ??
    6) need to add and check the rtcom here 



    after that -> we can connect the camera and the lidar and continue with the part of the tf map and autnimous  
