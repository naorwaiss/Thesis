#include <Arduino.h>
// #include "RTCom/RTCom.h"
#include <AlfredoCRSF.h>
#include <Encoder.h>

#define NUM_CHANNELS 14
#define ENCODER_RESOLOTION 2252

#define BUF Serial.print("/ ")
#define down Serial.println()
#define crsfSerial Serial1  // Use Serial1 for the CRSF communication

struct Motor_Data {
    const int pwmh_pin;
    const int dir_pin;
    int pwm_value;
    bool direction;
    const int encoderA_pin;
    const int encoderB_pin;
    long encoder_read;
    float velcoity;
    float xk_1 = 0, vk_1 = 0, xk = 0, vk = 0, rk = 0;
    float a = 0.85, b = 0.005;
};

#ifndef GND_BOT_H
#define GND_BOT_H

namespace G_BOT {

extern Motor_Data right_motor;
extern Motor_Data left_motor;

void open_loop_pwm(uint16_t axis_data, Motor_Data &motor);
void get_velocity_prediction(Motor_Data &motor, Encoder &encoder, double dt);
void executed_ch();
void init();
void main();

}  // namespace G_BOT

#endif
